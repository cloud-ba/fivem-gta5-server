# esx_voice
FXServer ESX Voice


#### Description
This is a proximity voice controller script. The default control for this is `Left Shift + H` (QWERTY).

#### Download

**1) Using [fvm](https://github.com/qlaffont/fvm-installer)**
```
fvm install --save --folder=esx esx-org/esx_voice
```

**2) Manually**
- Download https://github.com/ESX-Org/esx_voice/releases/latest
- Put it in resource/[esx] directory

**3) Using Git**

```
cd resouces
git clone https://github.com/ESX-Org/esx_voice
```

#### Installation

1) Add `start esx_voice` to your server.cfg


#### Credits
Original Script by [aabbfive](https://github.com/aabbfive/voicecontroller)
