Locales ['sv'] = {
  ['voice']   = '~y~Röst: ~s~%s',
  ['normal']  = 'prata',
  ['shout']   = 'skrik',
  ['whisper'] = 'viska',
}
