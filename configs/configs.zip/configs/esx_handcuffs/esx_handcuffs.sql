INSERT INTO `items` (`id`, `name`, `label`, `limit`, `rare`, `can_remove`) VALUES (NULL, 'handcuffs', 'Menottes', -1, 0, 1);
INSERT INTO `items` (`id`, `name`, `label`, `limit`, `rare`, `can_remove`) VALUES (NULL, 'key', 'Clé des menottes', -1, 0, 1);
