INSERT INTO `items` (name, label) VALUES 
	('gym_membership', 'Gym Membership'),
	('powerade', 'Powerade'),
	('sportlunch', 'Sportlunch'),
	('protein_shake', 'Protein Shake')
;