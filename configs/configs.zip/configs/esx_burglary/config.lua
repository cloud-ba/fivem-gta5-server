Config                = {}

Config.GiveBlack      = true -- If it should give black money
Config.AlertPolice    = true -- If the police should be alerted if someone fails a burglary

Config.DiscordWebhook = false
Config.WebhookUrl     = "url to webhook"

Config.BlipTime       = 2 * 60 * 1000 -- time that region of burglary will show on map (2 min default)