Locales['fr'] = {
	
	['used_beer'] = 'Vous avez utilisé 1x ~y~Bière~s~',

}