INSERT INTO `items` (`id`, `name`, `label`, `limit`, `rare`, `can_remove`, `can_steal`) VALUES
(NULL, 'firstaidkit', 'Kit de survi', -1, 0, 1, 1),
(NULL, 'defibrillateur', 'Defibrillateur', -1, 0, 1, 1);